package com.phoenixloader;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Shared preset storage. The native Phoenix UI can read/write the selected
 * cosmetic preset through this provider without accessing another app's private files.
 * Data is deliberately limited to non-secret UI/ESP preferences.
 */
public final class ProfilesProvider extends ContentProvider {
    static final String AUTHORITY = "com.phoenixloader.profiles";
    static final Uri PROFILES_URI = Uri.parse("content://" + AUTHORITY + "/profiles");
    static final Uri ACTIVE_URI = Uri.parse("content://" + AUTHORITY + "/active");
    static final String DEFAULT = "Default";

    @Override public boolean onCreate() {
        try { ensureDefault(getContext()); return true; }
        catch (IOException error) { android.util.Log.e("Phoenix", "Preset initialization failed", error); return false; }
    }

    static File directory(Context context) {
        return new File(context.getFilesDir(), "profiles");
    }

    static void validateName(String name) {
        if (name == null || name.length() < 1 || name.length() > 32 ||
                !name.matches("[\\p{L}0-9 _-]+") || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Имя: 1–32 символа (буквы, цифры, пробел, _ или -)");
        }
    }

    static File file(Context context, String name) {
        validateName(name);
        return new File(directory(context), name + ".cfg");
    }

    static void ensureDefault(Context context) throws IOException {
        File dir = directory(context);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create profiles");
        File def = file(context, DEFAULT);
        if (!def.exists()) {
            byte[] content = ("# Phoenix configuration v1\n"
                    + "visual.cornerBox=1\nvisual.skeleton=0\nvisual.playerInfo=0\n"
                    + "visual.playerName=1\nvisual.playerHealth=1\nvisual.playerDistance=1\n"
                    + "visual.healthBar=0\nvisual.weapon=0\nvisual.snapline=0\n"
                    + "visual.vehicle=0\nvisual.lootbox=0\nvisual.airdrop=0\n"
                    + "visual.item=0\nvisual.grenade=0\n"
                    + "color.cornerBox=FFFF5151\ncolor.skeleton=FF75D7C9\n"
                    + "color.playerInfo=FFE4E4E7\ncolor.healthBar=FF32DC78\n"
                    + "color.weapon=FFD4D4D8\ncolor.snapline=FF4BF0A0\n"
                    + "color.vehicle=FFFFD74B\ncolor.lootbox=FF8B5CF6\n"
                    + "color.airdrop=FFFF496B\ncolor.item=FFFFA500\n"
                    + "color.grenade=FFFF5533\ncolor.fovCircle=5FD4D4D8\n"
                    + "combat.aimFovMode=0\ncombat.aimFovDegrees=60\n"
                    + "combat.aimRadiusPx=220\ncombat.aimSmoothValue=3\n"
                    + "ui.fovCircleThickness=1.2\n"
                    + "ui.scrollbar=14\nui.watermarkScale=1\n"
                    + "ui.watermarkX=0.5\nui.watermarkY=0.02\n")
                    .getBytes("UTF-8");
            try (FileOutputStream out = new FileOutputStream(def)) {
                out.write(content);
                out.getFD().sync();
            }
        }
    }

    static String activeName(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("phoenix_profiles", Context.MODE_PRIVATE);
        String name = prefs.getString("active", DEFAULT);
        try {
            return file(context, name).isFile() ? name : DEFAULT;
        } catch (IllegalArgumentException ignored) {
            return DEFAULT;
        }
    }

    static void select(Context context, String name) throws IOException {
        ensureDefault(context);
        if (!file(context, name).isFile()) throw new IOException("Конфиг не найден: " + name);
        context.getSharedPreferences("phoenix_profiles", Context.MODE_PRIVATE)
                .edit().putString("active", name).apply();
    }

    static File[] list(Context context) {
        File[] files = directory(context).listFiles((dir, name) ->
                name.endsWith(".cfg") && !name.startsWith("."));
        if (files == null) return new File[0];
        Arrays.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        return files;
    }

    static void create(Context context, String name, String from) throws IOException {
        ensureDefault(context);
        File target = file(context, name);
        if (target.exists()) throw new IOException("Конфиг уже существует");
        File source = file(context, from);
        if (!source.isFile()) source = file(context, DEFAULT);
        File tmp = new File(directory(context), "." + name + ".tmp");
        try (java.io.FileInputStream input = new java.io.FileInputStream(source);
             FileOutputStream output = new FileOutputStream(tmp)) {
            byte[] data = new byte[8192];
            int count;
            while ((count = input.read(data)) != -1) output.write(data, 0, count);
            output.getFD().sync();
        }
        if (!tmp.renameTo(target)) {
            tmp.delete();
            throw new IOException("Не удалось создать конфиг");
        }
    }

    static void delete(Context context, String name) throws IOException {
        if (DEFAULT.equals(name)) throw new IOException("Нельзя удалить Default");
        File target = file(context, name);
        if (!target.isFile() || !target.delete()) throw new IOException("Не удалось удалить конфиг");
        if (activeName(context).equals(name)) select(context, DEFAULT);
    }

    private void checkCaller() {
        int uid = android.os.Binder.getCallingUid();
        if (uid == android.os.Process.myUid()) return;
        String[] packages = getContext().getPackageManager().getPackagesForUid(uid);
        String selectedRegion = getContext()
                .getSharedPreferences("phoenix_settings", Context.MODE_PRIVATE)
                .getString("selected_game_region", "VIETNAM");
        String allowedPackage;
        switch (selectedRegion) {
            case "GLOBAL": allowedPackage = "com.tencent.ig"; break;
            case "TAIWAN": allowedPackage = "com.rekoo.pubgm"; break;
            case "KOREA": allowedPackage = "com.pubg.krmobile"; break;
            case "INDIA": allowedPackage = "com.pubg.imobile"; break;
            default: allowedPackage = "com.vng.pubgmobile";
        }
        if (packages != null) {
            for (String pkg : packages) if (allowedPackage.equals(pkg)) return;
        }
        throw new SecurityException("Not authorized to access Phoenix presets");
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        checkCaller();
        Context ctx = getContext();
        if (ctx == null) return null;
        try { ensureDefault(ctx); }
        catch (IOException error) { return null; }
        MatrixCursor cursor = new MatrixCursor(new String[]{"name"});
        if ("/profiles".equals(uri.getPath())) {
            for (File file : list(ctx)) {
                cursor.addRow(new Object[]{file.getName().substring(0, file.getName().length()-4)});
            }
        } else if ("/active".equals(uri.getPath())) {
            cursor.addRow(new Object[]{activeName(ctx)});
        } else return null;
        return cursor;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode)
            throws java.io.FileNotFoundException {
        checkCaller();
        Context ctx = getContext();
        if (ctx == null || !"/active".equals(uri.getPath()))
            throw new java.io.FileNotFoundException("Unknown profile URI");
        try { ensureDefault(ctx); }
        catch (IOException error) { throw new java.io.FileNotFoundException(error.getMessage()); }
        File active = file(ctx, activeName(ctx));
        int flags;
        if ("r".equals(mode)) flags = ParcelFileDescriptor.MODE_READ_ONLY;
        else if ("w".equals(mode) || "wt".equals(mode))
            flags = ParcelFileDescriptor.MODE_WRITE_ONLY | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE;
        else throw new java.io.FileNotFoundException("Unsupported mode");
        return ParcelFileDescriptor.open(active, flags);
    }

    @Override public Uri insert(Uri uri, ContentValues values) {
        checkCaller();
        if (!"/profiles".equals(uri.getPath()) || values == null) return null;
        String name = values.getAsString("name");
        try {
            create(getContext(), name, activeName(getContext()));
            return Uri.withAppendedPath(PROFILES_URI, Uri.encode(name));
        } catch (IOException | IllegalArgumentException error) {
            throw new IllegalArgumentException(error.getMessage(), error);
        }
    }

    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) {
        checkCaller();
        if (!"/active".equals(uri.getPath()) || values == null) return 0;
        try {
            select(getContext(), values.getAsString("name"));
            return 1;
        } catch (IOException | IllegalArgumentException error) { return 0; }
    }

    @Override public int delete(Uri uri, String selection, String[] args) {
        checkCaller();
        if (!"/profiles".equals(uri.getPath()) || TextUtils.isEmpty(selection)) return 0;
        try { delete(getContext(), selection); return 1; }
        catch (IOException | IllegalArgumentException error) { return 0; }
    }

    @Override public String getType(Uri uri) { return "text/plain"; }
}
