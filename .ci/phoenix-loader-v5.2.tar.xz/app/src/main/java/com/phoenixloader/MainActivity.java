package com.phoenixloader;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Minimal, material-tonal Phoenix launcher. Internal file details stay out of the UI. */
public final class MainActivity extends Activity {
    private static final String GAME_PACKAGE = "com.vng.pubgmobile";
    private static final String PUBLIC_SO = "/data/local/tmp/libPhoenix.so";
    private static final String PUBLIC_INJECTOR = "/data/local/tmp/AndKittyInjector";
    private static final String SO_URL =
            "https://phoenix-licence.duckdns.org/downloads/libPhoenix.so";
    private static final String INJECTOR_ZIP_URL =
            "https://github.com/MJx0/AndKittyInjector/releases/download/v6.1.0/arm64-v8a.zip";
    private static final long MAX_SO_BYTES = 128L * 1024 * 1024;
    private static final long MAX_ZIP_BYTES = 128L * 1024 * 1024;
    private static final long MAX_INJECTOR_BYTES = 48L * 1024 * 1024;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private int backgroundColor;
    private int surfaceColor;
    private int surfaceHighColor;
    private int accentColor;
    private int textColor;
    private int mutedColor;
    private int errorColor;
    private final int onAccentColor = 0xff10302d;

    private File workspace;
    private File libraryFile;
    private File injectorZipFile;
    private File injectorFile;
    private volatile boolean destroyed;
    private volatile Process activeRootProcess;
    private volatile Process rootProbe;
    private boolean busy;
    private boolean rootChecking;
    private boolean rootGranted;
    private int rootCheckGeneration;

    private FrameLayout screen;
    private TextView rootStatus;
    private TextView readyText;
    private View readyDot;
    private TextView progressText;
    private ProgressBar progressBar;
    private TextView launchButton;
    private TextView prepareButton;
    private Dialog currentDialog;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backgroundColor = dynamic("system_neutral1_900", 0xff0c1316);
        surfaceColor = dynamic("system_neutral1_800", 0xff192226);
        surfaceHighColor = dynamic("system_neutral1_700", 0xff253134);
        accentColor = dynamic("system_accent1_200", 0xff9fe8d8);
        textColor = dynamic("system_neutral1_50", 0xfff0f7f6);
        mutedColor = dynamic("system_neutral2_300", 0xffa2b4b5);
        errorColor = dynamic("system_error_200", 0xffffb4ab);
        getWindow().setStatusBarColor(backgroundColor);
        getWindow().setNavigationBarColor(backgroundColor);
        getWindow().getDecorView().setSystemUiVisibility(0);
        workspace = new File(getFilesDir(), "phoenix_data");
        libraryFile = new File(workspace, "libPhoenix.so");
        injectorZipFile = new File(workspace, "arm64-v8a.zip");
        injectorFile = new File(workspace, "AndKittyInjector");
        showHome();
        checkRootAccess();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        rootCheckGeneration++;
        if (rootProbe != null) rootProbe.destroy();
        if (activeRootProcess != null) activeRootProcess.destroy();
        if (currentDialog != null) currentDialog.dismiss();
        executor.shutdownNow();
        super.onDestroy();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int dynamic(String name, int fallback) {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            int id = getResources().getIdentifier(name, "color", "android");
            if (id != 0) try { return getColor(id); } catch (Exception ignored) { }
        }
        return fallback;
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private GradientDrawable stroked(int color, float radius) {
        GradientDrawable drawable = rounded(color, radius);
        drawable.setStroke(dp(1), 0x446b9090);
        return drawable;
    }

    private GradientDrawable gradient(int a, int b, float radius) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{a,b});
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), 0x3340a9a0);
        return drawable;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private TextView text(String label, int size, int color, boolean medium) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        view.setIncludeFontPadding(false);
        return view;
    }

    private void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        parent.addView(child, p);
    }

    private ImageView icon(int resource, int color, int size) {
        ImageView image = new ImageView(this);
        image.setImageResource(resource);
        image.setImageTintList(ColorStateList.valueOf(color));
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return image;
    }

    private TextView pill(String value) {
        TextView label = text(value, 11, accentColor, true);
        label.setLetterSpacing(0.10f);
        label.setPadding(dp(13), dp(8), dp(13), dp(8));
        label.setBackground(rounded(0x352ca99a, 15));
        return label;
    }

    private TextView button(String title, boolean strong) {
        TextView b = text(title, 16, strong ? onAccentColor : textColor, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(58));
        b.setPadding(dp(18), dp(15), dp(18), dp(15));
        GradientDrawable bg = strong ? rounded(accentColor, 20) : stroked(surfaceHighColor, 20);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff), bg, null));
        b.setClickable(true);
        b.setFocusable(true);
        int symbol = "Запустить".equals(title) ? R.drawable.ic_arrow_line
                : "Подготовить".equals(title) ? R.drawable.ic_download_line : 0;
        if (symbol != 0) {
            Drawable drawable = getDrawable(symbol).mutate();
            drawable.setColorFilter(strong ? onAccentColor : textColor, PorterDuff.Mode.SRC_IN);
            drawable.setBounds(0, 0, dp(20), dp(20));
            b.setCompoundDrawables(drawable, null, null, null);
            b.setCompoundDrawablePadding(dp(12));
        }
        return b;
    }

    private void showHome() {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(backgroundColor);
        setContentView(screen);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        screen.addView(scroll, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout body = vertical();
        body.setPadding(dp(22), dp(25), dp(22), dp(28));
        scroll.addView(body, new ScrollView.LayoutParams(-1,-2));

        LinearLayout header = horizontal();
        FrameLayout emblem = new FrameLayout(this);
        emblem.setBackground(rounded(surfaceHighColor, 17));
        ImageView logo = icon(R.drawable.ic_phoenix_glyph, accentColor, 28);
        FrameLayout.LayoutParams glyphParams = new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.CENTER);
        emblem.addView(logo,glyphParams);
        header.addView(emblem,new LinearLayout.LayoutParams(dp(52),dp(52)));

        LinearLayout name = vertical();
        name.setPadding(dp(13), 0, 0, 0);
        add(name, text("PHOENIX", 23, textColor, true), 0);
        TextView edition = text("PRIVATE EDITION", 10, mutedColor, true);
        edition.setLetterSpacing(0.18f);
        add(name, edition, 6);
        header.addView(name,new LinearLayout.LayoutParams(0,-2,1));

        FrameLayout aboutFrame = new FrameLayout(this);
        aboutFrame.setBackground(new RippleDrawable(ColorStateList.valueOf(0x35ffffff),
                rounded(surfaceColor, 16),null));
        aboutFrame.addView(icon(R.drawable.ic_info_line,textColor,21),
                new FrameLayout.LayoutParams(dp(21),dp(21),Gravity.CENTER));
        header.addView(aboutFrame,new LinearLayout.LayoutParams(dp(46),dp(46)));
        aboutFrame.setOnClickListener(v -> showCustomDialog("О Phoenix",
                "Лаконичный лаунчер с автоматической подготовкой и запуском. Настройки находятся внутри основного меню.",
                "Понятно",null,null));
        add(body,header,0);

        // Hero surface: one clear action, without technical file names.
        LinearLayout hero = vertical();
        hero.setPadding(dp(24),dp(27),dp(24),dp(27));
        hero.setBackground(gradient(0xff193b39,0xff1c292f,30));
        hero.setElevation(dp(2));
        LinearLayout eyebrow = horizontal();
        eyebrow.addView(icon(R.drawable.ic_sparkle_line,accentColor,17));
        TextView eyebrowLabel = text("  ДОБРО ПОЖАЛОВАТЬ", 11, accentColor, true);
        eyebrowLabel.setLetterSpacing(0.10f);
        eyebrow.addView(eyebrowLabel);
        add(hero,eyebrow,0);
        add(hero,text("Всё готово к\nтвоему старту.", 29, textColor, true),20);
        TextView subtitle = text("Один запуск. Никаких лишних действий.", 14, 0xffb5cccb, false);
        subtitle.setLineSpacing(dp(3),1f);
        add(hero,subtitle,12);
        LinearLayout heroFooter = horizontal();
        heroFooter.addView(pill("PHOENIX · 5.2"));
        add(hero,heroFooter,26);
        add(body,hero,31);

        TextView section = text("Состояние", 20, textColor, true);
        add(body,section,31);
        LinearLayout status = vertical();
        status.setPadding(dp(20),dp(20),dp(20),dp(20));
        status.setBackground(stroked(surfaceColor,24));

        LinearLayout access = horizontal();
        FrameLayout shieldPlate = new FrameLayout(this);
        shieldPlate.setBackground(rounded(surfaceHighColor,13));
        shieldPlate.addView(icon(R.drawable.ic_shield_line,accentColor,21),
                new FrameLayout.LayoutParams(dp(21),dp(21),Gravity.CENTER));
        access.addView(shieldPlate,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout rootDescription = vertical();
        rootDescription.setPadding(dp(14),0,0,0);
        add(rootDescription,text("Root-доступ",15,textColor,true),0);
        rootStatus = text("Проверяем разрешение…",12,mutedColor,false);
        add(rootDescription,rootStatus,6);
        access.addView(rootDescription,new LinearLayout.LayoutParams(0,-2,1));
        add(status,access,0);
        View separator = new View(this);
        separator.setBackgroundColor(0x305c8084);
        LinearLayout.LayoutParams separatorParams = new LinearLayout.LayoutParams(-1,dp(1));
        separatorParams.topMargin=dp(17); separatorParams.bottomMargin=dp(17);
        status.addView(separator,separatorParams);

        LinearLayout contentStatus = horizontal();
        readyDot = new View(this);
        readyDot.setBackground(rounded(mutedColor,8));
        contentStatus.addView(readyDot,new LinearLayout.LayoutParams(dp(8),dp(8)));
        LinearLayout contentLabels = vertical();
        contentLabels.setPadding(dp(14),0,0,0);
        add(contentLabels,text("Подготовка",15,textColor,true),0);
        readyText = text("Проверка компонентов…",12,mutedColor,false);
        add(contentLabels,readyText,6);
        contentStatus.addView(contentLabels,new LinearLayout.LayoutParams(0,-2,1));
        add(status,contentStatus,0);
        add(body,status,14);

        launchButton = button("Запустить",true);
        add(body,launchButton,27);
        launchButton.setOnClickListener(v -> {
            if (!requireRoot()) return;
            confirmRootLoad(true);
        });
        prepareButton = button("Подготовить",false);
        add(body,prepareButton,11);
        prepareButton.setOnClickListener(v -> {
            if (!requireRoot()) return;
            prepareFiles(false);
        });

        LinearLayout progress = vertical();
        progress.setPadding(dp(4),dp(10),dp(4),dp(8));
        progressText = text("Ожидание",13,mutedColor,false);
        add(progress,progressText,0);
        progressBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(accentColor));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(surfaceHighColor));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(3));
        p.topMargin=dp(13);
        progress.addView(progressBar,p);
        add(body,progress,12);
        TextView foot = text("Управление и персонализация — внутри меню",12,mutedColor,false);
        foot.setGravity(Gravity.CENTER);
        add(body,foot,17);
        updateRootState();
        updateReadyState();
        setWorking(busy);
    }

    private void setWorking(boolean working) {
        boolean active = !working && rootGranted;
        if (launchButton != null) launchButton.setEnabled(active);
        if (prepareButton != null) prepareButton.setEnabled(active);
        if (launchButton != null) launchButton.setAlpha(active ? 1f : 0.5f);
        if (prepareButton != null) prepareButton.setAlpha(active ? 1f : 0.5f);
    }

    private void updateRootState() {
        if (rootStatus != null) {
            String state = rootChecking ? "Запрашиваем разрешение…"
                    : rootGranted ? "Доступ подтверждён" : "Нужен root-доступ";
            rootStatus.setText(state);
            rootStatus.setTextColor(rootGranted ? accentColor : rootChecking ? mutedColor : errorColor);
        }
        setWorking(busy);
    }

    private void checkRootAccess() {
        if (rootChecking || busy || destroyed) return;
        rootChecking = true;
        rootGranted = false;
        updateRootState();
        final int generation = ++rootCheckGeneration;
        executor.execute(() -> {
            Process process = null;
            boolean granted = false;
            try {
                process = new ProcessBuilder("su", "-c", "id -u")
                        .redirectErrorStream(true).start();
                rootProbe = process;
                final Process probe = process;
                ui.postDelayed(() -> {
                    if (!destroyed && rootChecking && rootProbe == probe) probe.destroy();
                }, 14000);
                int code = process.waitFor();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line = reader.readLine();
                    granted = code == 0 && "0".equals(line == null ? "" : line.trim());
                }
            } catch (Exception ignored) {
                granted = false;
            } finally {
                if (rootProbe == process) rootProbe = null;
                if (process != null) process.destroy();
            }
            final boolean success = granted;
            ui.post(() -> {
                if (destroyed || generation != rootCheckGeneration) return;
                rootChecking = false;
                rootGranted = success;
                updateRootState();
                if (!success) showRootRequired();
            });
        });
    }

    private boolean requireRoot() {
        if (!rootGranted) {
            showRootRequired();
            return false;
        }
        return true;
    }

    private void showRootRequired() {
        showCustomDialog("Запустите с Root-доступом",
                "Phoenix требует root-разрешение. Предоставь его в менеджере root и повтори проверку.",
                "Повторить проверку",this::checkRootAccess,"Закрыть");
    }

    private void showIssue(String title, String message) {
        showCustomDialog(title,message,"Понятно",null,null);
    }

    private void showLaunchIssue(String error) {
        String title = "Не удалось запустить";
        String detail = "Повтори попытку. Если ошибка сохраняется, проверь соединение и доступ к игре.";
        String lower = error.toLowerCase(Locale.ROOT);
        if (lower.contains("su") || lower.contains("root") || lower.contains("permission denied")) {
            title = "Недостаточно прав";
            detail = "Root-доступ недоступен. Проверь разрешение для Phoenix в менеджере root.";
            rootGranted = false;
            updateRootState();
        } else if (lower.contains("http") || lower.contains("connect") || lower.contains("сеть") || lower.contains("zip")) {
            title = "Не удалось подготовить";
            detail = "Проверь подключение к интернету и повтори подготовку.";
        } else if (lower.contains("pubg") || lower.contains("process not ready")) {
            title = "Игра не готова";
            detail = "Убедись, что игра установлена, и повтори запуск.";
        }
        showCustomDialog(title,detail,"Понятно",null,null);
    }

    private void confirmRootLoad(final boolean updateFiles) {
        if (busy || destroyed || !requireRoot()) return;
        showCustomDialog("Начать запуск?",
                "Phoenix выполнит подготовку и откроет игру. Для этого будут использованы разрешённые тобой повышенные права.",
                "Продолжить", () -> {
                    if (updateFiles) prepareFiles(true); else loadPreparedFiles();
                },"Отмена");
    }

    /** All dialogs are custom view-based Material-tonal surfaces, not system alert dialogs. */
    private void showCustomDialog(String title, String message, String mainLabel,
                                  Runnable action, String cancelLabel) {
        if (destroyed || isFinishing()) return;
        if (currentDialog != null && currentDialog.isShowing()) currentDialog.dismiss();
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        LinearLayout sheet = vertical();
        sheet.setPadding(dp(24),dp(24),dp(24),dp(24));
        sheet.setBackground(stroked(surfaceColor,28));
        LinearLayout row = horizontal();
        FrameLayout mark = new FrameLayout(this);
        mark.setBackground(rounded(surfaceHighColor,15));
        mark.addView(icon(R.drawable.ic_info_line,accentColor,22),
                new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.CENTER));
        row.addView(mark,new LinearLayout.LayoutParams(dp(46),dp(46)));
        add(sheet,row,0);
        add(sheet,text(title,23,textColor,true),20);
        TextView description = text(message,14,mutedColor,false);
        description.setLineSpacing(dp(4),1f);
        add(sheet,description,11);
        TextView main = button(mainLabel,true);
        add(sheet,main,27);
        main.setOnClickListener(v -> {
            dialog.dismiss();
            if (action != null) action.run();
        });
        if (cancelLabel != null) {
            TextView dismiss = button(cancelLabel,false);
            add(sheet,dismiss,10);
            dismiss.setOnClickListener(v->dialog.dismiss());
        }
        dialog.setContentView(sheet);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.width = getResources().getDisplayMetrics().widthPixels - dp(42);
            attributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
            attributes.dimAmount = 0.62f;
            attributes.gravity = Gravity.CENTER;
            window.setAttributes(attributes);
        }
        currentDialog = dialog;
        dialog.show();
        if (window != null) window.setLayout(getResources().getDisplayMetrics().widthPixels - dp(42),-2);
    }

    private void prepareFiles(final boolean launchAfterDownload) {
        if (busy || destroyed) return;
        busy = true;
        setWorking(true);
        if (progressBar != null) progressBar.setProgress(0);
        if (progressText != null) progressText.setText("Подключение к серверу...");
        log("Начата загрузка новой версии файлов");

        executor.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!workspace.isDirectory() && !workspace.mkdirs()) {
                        throw new IOException("Не удалось создать папку приложения");
                    }

                    stage(2, "Подготовка...");
                    downloadHttps(SO_URL, libraryFile, MAX_SO_BYTES, 3, 52);
                    verifyArm64Elf(libraryFile, "libPhoenix.so");
                    log("libPhoenix.so: " + libraryFile.length() + " байт");
                    log("SHA-256: " + sha256(libraryFile));

                    stage(58, "Подготовка...");
                    downloadHttps(INJECTOR_ZIP_URL, injectorZipFile,
                            MAX_ZIP_BYTES, 59, 23);
                    stage(84, "Подготовка...");
                    unpackInjector(injectorZipFile, injectorFile);
                    verifyArm64Elf(injectorFile, "AndKittyInjector");
                    log("Архив распакован: AndKittyInjector найден");
                    stage(100, "Оба файла подготовлены");

                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            updateReadyState();
                            if (launchAfterDownload) {
                                // Keep busy and progress running until root operation has finished.
                                executeRootLoad();
                            } else {
                                finishWork();
                            }
                        }
                    });
                } catch (final Exception error) {
                    log("ОШИБКА: " + messageOf(error));
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            if (progressText != null) progressText.setText("Подготовка прервана");
                            updateReadyState();
                            finishWork();
                            showLaunchIssue(messageOf(error));
                        }
                    });
                }
            }
        });
    }

    private void finishWork() {
        busy = false;
        setWorking(false);
    }

    private void loadPreparedFiles() {
        if (busy || destroyed) return;
        if (!isArm64Elf(libraryFile) || !isArm64Elf(injectorFile)) {
            log("Сначала скачайте оба компонента");
            showIssue("Нужна подготовка", "Сначала нажми «Подготовить», чтобы получить необходимые компоненты.");
            return;
        }
        busy = true;
        setWorking(true);
        executeRootLoad();
    }

    private void executeRootLoad() {
        if (destroyed) return;
        executor.execute(new Runnable() {
            @Override public void run() {
                try {
                    verifyArm64Elf(libraryFile, "libPhoenix.so");
                    verifyArm64Elf(injectorFile, "AndKittyInjector");
                    stage(88, "Проверка root и подготовка файлов...");
                    log("Проверяем права su");
                    runRoot("test \"$(id -u)\" = 0", false);

                    // The original successful manual run used these public paths.
                    // Quote source paths even though they originate from getFilesDir().
                    String prepare = "set -e; "
                            + "cp " + shellQuote(libraryFile.getAbsolutePath())
                            + " " + shellQuote(PUBLIC_SO) + "; "
                            + "chmod 644 " + shellQuote(PUBLIC_SO) + "; "
                            + "cp " + shellQuote(injectorFile.getAbsolutePath())
                            + " " + shellQuote(PUBLIC_INJECTOR) + "; "
                            + "chmod 700 " + shellQuote(PUBLIC_INJECTOR) + "; "
                            + "test -s " + shellQuote(PUBLIC_SO) + "; "
                            + "test -x " + shellQuote(PUBLIC_INJECTOR);
                    runRoot(prepare, false);
                    log("Файлы подготовлены в /data/local/tmp");

                    final Intent intent = getPackageManager()
                            .getLaunchIntentForPackage(GAME_PACKAGE);
                    if (intent == null) {
                        throw new IOException("PUBG Mobile VN не установлена или недоступна");
                    }

                    stage(92, "Открытие игры без остановки процесса...");
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            try {
                                startActivity(intent);
                                log("Игра открыта через Intent");
                            } catch (Exception error) {
                                log("Ошибка открытия игры: " + messageOf(error));
                            }
                        }
                    });

                    // Wait until the target's native engine has appeared.
                    // Do not kill/restart the game; target may already be running.
                    stage(95, "Ожидание готовности процесса...");
                    String injection = "found=0; n=0; "
                            + "while [ \"$n\" -lt 120 ]; do "
                            + "  pid=$(pidof " + GAME_PACKAGE + " 2>/dev/null); "
                            + "  pid=${pid%% *}; "
                            + "  if [ -n \"$pid\" ] && [ -r \"/proc/$pid/maps\" ] "
                            + "     && grep -q 'libUE4.so' \"/proc/$pid/maps\"; then "
                            + "    found=1; break; "
                            + "  fi; "
                            + "  sleep 1; n=$((n + 1)); "
                            + "done; "
                            + "if [ \"$found\" -ne 1 ]; then echo 'PUBG process not ready'; exit 124; fi; "
                            + "sleep 5; "
                            + shellQuote(PUBLIC_INJECTOR)
                            + " --package " + shellQuote(GAME_PACKAGE)
                            + " --libs " + shellQuote(PUBLIC_SO);
                    stage(97, "Запуск...");
                    runRoot(injection, true);
                    stage(100, "Команда завершилась успешно");
                    log("Подготовка запуска завершена");
                } catch (final Exception error) {
                    log("ОШИБКА: " + messageOf(error));
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) {
                                if (progressText != null) progressText.setText("Ошибка запуска");
                                showLaunchIssue(messageOf(error));
                            }
                        }
                    });
                } finally {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) {
                                finishWork();
                                updateReadyState();
                            }
                        }
                    });
                }
            }
        });
    }

    /** One safely quoted POSIX-shell argument. */
    private static String shellQuote(String value) {
        return "'" + value.replace("'", "'\"'\"'") + "'";
    }

    /** Run a single explicit command under su and record its stdout/stderr. */
    private void runRoot(String command, boolean showOutput) throws IOException {
        Process process = null;
        StringBuilder recentOutput = new StringBuilder();
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            activeRootProcess = process;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (showOutput) log("[root] " + line);
                    recentOutput.append(line).append('\n');
                    if (recentOutput.length() > 4000) {
                        recentOutput.delete(0, recentOutput.length() - 4000);
                    }
                }
            }
            int code = process.waitFor();
            if (code != 0) {
                String details = recentOutput.toString().trim();
                if (details.length() > 180) {
                    details = details.substring(details.length() - 180);
                }
                throw new IOException("su: код выхода " + code
                        + (details.isEmpty() ? "" : ": " + details));
            }
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new IOException("Root-команда прервана", error);
        } finally {
            activeRootProcess = null;
            if (process != null) process.destroy();
        }
    }

    private void updateReadyState() {
        if (destroyed) return;
        boolean ready = isArm64Elf(libraryFile) && isArm64Elf(injectorFile);
        if (ready && !busy) {
            if (progressBar != null) progressBar.setProgress(100);
            if (progressText != null) progressText.setText("Готово к запуску");
        }
        if (readyText != null) {
            readyText.setText(ready ? "Компоненты готовы" : "Ожидает подготовки");
            readyText.setTextColor(ready ? accentColor : mutedColor);
        }
        if (readyDot != null) readyDot.setBackground(rounded(ready ? accentColor : mutedColor, 8));
    }

    private void stage(final int percent, final String ignored) {
        ui.post(() -> {
            if (destroyed) return;
            if (progressBar != null) progressBar.setProgress(percent);
            if (progressText != null) {
                String status = percent < 85 ? "Подготовка…"
                        : percent < 100 ? "Запуск…" : "Готово";
                progressText.setText(status);
            }
        });
    }

    /** Download to a temporary file, then replace only after full transfer. */
    private void downloadHttps(String address, File target, long maxBytes,
                               int progressBase, int progressSpan) throws IOException {
        HttpURLConnection connection = openHttps(address);
        File temporary = File.createTempFile(".phoenix-", ".download", workspace);
        try {
            long declaredSize = connection.getContentLengthLong();
            if (declaredSize > maxBytes) {
                throw new IOException("Файл слишком большой");
            }
            long total = 0;
            byte[] buffer = new byte[16384];
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream output = new FileOutputStream(temporary)) {
                int count;
                int lastPercent = -1;
                while ((count = input.read(buffer)) != -1) {
                    if (count == 0) continue;
                    total += count;
                    if (total > maxBytes) throw new IOException("Лимит размера превышен");
                    output.write(buffer, 0, count);
                    if (declaredSize > 0) {
                        int part = (int) Math.min(progressSpan,
                                (total * progressSpan) / declaredSize);
                        int percent = progressBase + part;
                        if (percent > lastPercent) {
                            lastPercent = percent;
                            final int progress = percent;
                            ui.post(new Runnable() {
                                @Override public void run() {
                                    if (!destroyed && progressBar != null) progressBar.setProgress(progress);
                                }
                            });
                        }
                    }
                }
                output.getFD().sync();
            }
            if (total == 0) throw new IOException("Сервер прислал пустой файл");
            // Never replace the last usable file with an invalid download.
            if ("libPhoenix.so".equals(target.getName())) {
                verifyArm64Elf(temporary, "libPhoenix.so");
            } else if ("arm64-v8a.zip".equals(target.getName())) {
                verifyZipSignature(temporary);
            }
            if (!temporary.renameTo(target)) {
                throw new IOException("Не удалось сохранить " + target.getName());
            }
        } finally {
            connection.disconnect();
            if (temporary.exists()) temporary.delete();
        }
    }

    /** Follow HTTPS redirects, including GitHub release asset redirects. */
    private HttpURLConnection openHttps(String address) throws IOException {
        URL current = new URL(address);
        for (int i = 0; i < 8; i++) {
            if (!"https".equalsIgnoreCase(current.getProtocol())) {
                throw new IOException("Разрешён только HTTPS");
            }
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(45000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Cache-Control", "no-cache");
            connection.setRequestProperty("User-Agent", "Phoenix-Loader/4.0");
            int status;
            try {
                status = connection.getResponseCode();
            } catch (IOException error) {
                connection.disconnect();
                throw error;
            }
            if (status == 301 || status == 302 || status == 303 ||
                    status == 307 || status == 308) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("Нет адреса перенаправления");
                current = new URL(current, location);
                continue;
            }
            if (status != HttpURLConnection.HTTP_OK) {
                connection.disconnect();
                throw new IOException("HTTP " + status + " для " + current.getHost());
            }
            return connection;
        }
        throw new IOException("Слишком много перенаправлений");
    }

    private void verifyZipSignature(File file) throws IOException {
        byte[] header = new byte[4];
        try (InputStream input = new FileInputStream(file)) {
            int offset = 0;
            while (offset < 4) {
                int n = input.read(header, offset, 4 - offset);
                if (n < 0) break;
                offset += n;
            }
            if (offset != 4 || header[0] != 'P' || header[1] != 'K' ||
                    header[2] != 3 || header[3] != 4) {
                throw new IOException("Сервер вернул не ZIP-архив");
            }
        }
    }

    /** Extract only the executable, regardless of the archive's parent directory. */
    private void unpackInjector(File archive, File destination) throws IOException {
        File temporary = File.createTempFile(".injector-", ".tmp", workspace);
        boolean found = false;
        try {
            try (ZipInputStream zip = new ZipInputStream(
                    new BufferedInputStream(new FileInputStream(archive)))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String path = entry.getName().replace('\\', '/');
                    String basename = path.substring(path.lastIndexOf('/') + 1);
                    if (!entry.isDirectory() && "AndKittyInjector".equals(basename)) {
                        long count = 0;
                        try (OutputStream output = new BufferedOutputStream(
                                new FileOutputStream(temporary))) {
                            byte[] buffer = new byte[8192];
                            int n;
                            while ((n = zip.read(buffer)) != -1) {
                                if (n == 0) continue;
                                count += n;
                                if (count > MAX_INJECTOR_BYTES) {
                                    throw new IOException("Исполняемый файл слишком большой");
                                }
                                output.write(buffer, 0, n);
                            }
                        }
                        if (count == 0) throw new IOException("Пустой AndKittyInjector");
                        found = true;
                        zip.closeEntry();
                        break;
                    }
                    zip.closeEntry();
                }
            }
            if (!found) {
                throw new IOException("AndKittyInjector не найден внутри ZIP");
            }
            verifyArm64Elf(temporary, "AndKittyInjector");
            if (!temporary.renameTo(destination)) {
                throw new IOException("Не удалось сохранить AndKittyInjector");
            }
        } finally {
            if (temporary.exists()) temporary.delete();
        }
    }

    private boolean isArm64Elf(File file) {
        try {
            verifyArm64Elf(file, "Файл");
            return true;
        } catch (IOException error) {
            return false;
        }
    }

    private void verifyArm64Elf(File file, String name) throws IOException {
        if (file == null || !file.isFile() || file.length() < 20) {
            throw new IOException(name + ": файл отсутствует или повреждён");
        }
        byte[] magic = new byte[20];
        try (InputStream input = new FileInputStream(file)) {
            int read = 0;
            while (read < magic.length) {
                int n = input.read(magic, read, magic.length - read);
                if (n < 0) break;
                read += n;
            }
            if (read != magic.length || magic[0] != 0x7f || magic[1] != 'E' ||
                    magic[2] != 'L' || magic[3] != 'F' || magic[4] != 2 ||
                    magic[5] != 1 || (magic[18] & 0xff) != 183 || magic[19] != 0) {
                throw new IOException(name + ": ожидается ELF ARM64");
            }
        }
    }

    private String sha256(File file) throws IOException {
        final MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException error) {
            throw new IOException("SHA-256 недоступен", error);
        }
        try (InputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (count > 0) digest.update(buffer, 0, count);
            }
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte b : digest.digest()) {
            hex.append(String.format(Locale.US, "%02x", b & 0xff));
        }
        return hex.toString();
    }

    private void log(final String message) {
        // No user-visible or system log of component internals.
    }

    private static String messageOf(Throwable error) {
        String text = error.getMessage();
        return text == null || text.trim().isEmpty()
                ? error.getClass().getSimpleName() : text;
    }
}
