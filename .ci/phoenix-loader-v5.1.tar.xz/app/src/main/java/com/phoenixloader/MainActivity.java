package com.phoenixloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.SeekBar;
import java.util.Properties;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MainActivity extends Activity {
    private static final String GAME_PACKAGE = "com.vng.pubgmobile";
    private static final String PUBLIC_SO = "/data/local/tmp/libPhoenix.so";
    private static final String PUBLIC_INJECTOR = "/data/local/tmp/AndKittyInjector";
    private static final String SO_URL =
            "https://phoenix-licence.duckdns.org/downloads/libPhoenix.so";
    // Exact archive URL from the previous Phoenix Loader source.
    private static final String INJECTOR_ZIP_URL =
            "https://github.com/MJx0/AndKittyInjector/releases/download/v6.1.0/arm64-v8a.zip";

    private static final long MAX_SO_BYTES = 128L * 1024 * 1024;
    private static final long MAX_ZIP_BYTES = 128L * 1024 * 1024;
    private static final long MAX_INJECTOR_BYTES = 48L * 1024 * 1024;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private static final String[] VISUAL_KEYS = {
        "cornerBox", "skeleton", "playerInfo", "healthBar", "weapon", "snapline",
        "vehicle", "lootbox", "airdrop", "item", "grenade"
    };
    private static final String[] VISUAL_LABELS = {
        "Corner Box", "Skeleton", "Информация об игроке", "Health Bar", "Оружие", "Snapline",
        "Транспорт", "Lootbox", "AirDrop", "Предметы", "Гранаты"
    };
    private static final int[] COLOR_DEFAULTS = {
        0xffff5151, 0xff75d7c9, 0xffe4e4e7, 0xff32dc78, 0xffd4d4d8, 0xff4bf0a0,
        0xffffd74b, 0xff8b5cf6, 0xffff496b, 0xffffa500, 0xffff5533
    };

    private int backgroundColor, surfaceColor, surfaceHighColor;
    private int accentColor, textColor, mutedColor, errorColor, onAccentColor;
    private FrameLayout rootFrame;
    private int page = 0;
    private TextView libraryStatus, injectorStatus, progressText;
    private ProgressBar progressBar;
    private Button prepareButton, downloadButton, launchButton;

    private File workspace;
    private File libraryFile;
    private File injectorZipFile;
    private File injectorFile;
    private boolean busy;
    private volatile boolean destroyed;
    private volatile Process activeRootProcess;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        initPalette();
        getWindow().setStatusBarColor(backgroundColor);
        getWindow().setNavigationBarColor(surfaceColor);
        rootFrame = new FrameLayout(this);
        setContentView(rootFrame);
        workspace = new File(getFilesDir(), "phoenix_data");
        libraryFile = new File(workspace, "libPhoenix.so");
        injectorZipFile = new File(workspace, "arm64-v8a.zip");
        injectorFile = new File(workspace, "AndKittyInjector");
        showPage(0);
    }

    @Override public void onBackPressed() {
        if (page != 0) showPage(0);
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        Process process = activeRootProcess;
        if (process != null) process.destroy();
        executor.shutdownNow();
        super.onDestroy();
    }

    private int dp(float px) {
        return Math.round(px * getResources().getDisplayMetrics().density);
    }

    private int color(String systemName, int fallback) {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            int res = getResources().getIdentifier(systemName, "color", "android");
            if (res != 0) {
                try { return getColor(res); } catch (Exception ignored) { }
            }
        }
        return fallback;
    }

    private void initPalette() {
        backgroundColor = color("system_neutral1_900", 0xff101317);
        surfaceColor = color("system_neutral1_800", 0xff1d2228);
        surfaceHighColor = color("system_neutral1_700", 0xff2a3038);
        accentColor = color("system_accent1_200", 0xff93e5d7);
        textColor = color("system_neutral1_50", 0xfff0f3f5);
        mutedColor = color("system_neutral2_300", 0xffa9b5bd);
        errorColor = color("system_error_200", 0xffffb4ab);
        onAccentColor = 0xff0b2425;
    }

    private GradientDrawable rounded(int tint, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(tint);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private GradientDrawable bordered(int tint, int radius) {
        GradientDrawable shape = rounded(tint, radius);
        shape.setStroke(dp(1), 0x446e7782);
        return shape;
    }

    private void ripple(View view, int tint, int radius) {
        view.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x33ffffff), rounded(tint, radius), null));
        view.setClickable(true);
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private TextView text(String value, int size, int tint, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(tint);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        view.setIncludeFontPadding(false);
        return view;
    }

    private void stack(LinearLayout column, View view, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(top);
        column.addView(view, params);
    }

    private LinearLayout card(int pad) {
        LinearLayout layout = vertical();
        layout.setPadding(dp(pad), dp(pad), dp(pad), dp(pad));
        layout.setBackground(bordered(surfaceColor, 26));
        return layout;
    }

    private Button primary(String caption, boolean filled) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(caption);
        button.setTextSize(15);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setTextColor(filled ? onAccentColor : textColor);
        button.setBackground(filled ? rounded(accentColor, 20) : bordered(surfaceHighColor, 20));
        button.setMinHeight(dp(54));
        button.setElevation(0);
        button.setPadding(dp(16), dp(9), dp(16), dp(9));
        return button;
    }

    private void showPage(int next) {
        page = next;
        libraryStatus = null; injectorStatus = null;
        prepareButton = null; downloadButton = null; launchButton = null;
        progressBar = null; progressText = null;
        rootFrame.removeAllViews();
        LinearLayout shell = vertical();
        shell.setBackgroundColor(backgroundColor);
        rootFrame.addView(shell, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = vertical();
        body.setPadding(dp(20), dp(28), dp(20), dp(22));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        renderHeader(body);
        if (page == 0) renderHome(body);
        else if (page == 1) renderProfiles(body);
        else renderPreferences(body);
        renderNav(shell);
    }

    private void renderHeader(LinearLayout body) {
        LinearLayout header = horizontal();
        TextView logo = text("✦", 26, accentColor, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(rounded(surfaceHighColor, 20));
        header.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout names = vertical();
        names.setPadding(dp(14), 0, 0, 0);
        stack(names, text("Phoenix", 27, textColor, true), 0);
        stack(names, text("PRIVATE CONTROL CENTER", 10, mutedColor, true), 5);
        header.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        TextView version = text("v5", 13, accentColor, true);
        version.setPadding(dp(12), dp(8), dp(12), dp(8));
        version.setBackground(rounded(surfaceHighColor, 16));
        header.addView(version);
        stack(body, header, 0);
    }

    private void renderHome(LinearLayout body) {
        stack(body, text("Всё под контролем", 28, textColor, true), 35);
        stack(body, text("Компоненты, запуск и состояние системы в одном месте.", 14, mutedColor, false), 8);
        LinearLayout status = card(18);
        stack(status, text("СТАТУС СИСТЕМЫ", 11, mutedColor, true), 0);
        LinearLayout first = horizontal();
        first.addView(text("Phoenix · ARM64", 16, textColor, true), new LinearLayout.LayoutParams(0, -2, 1));
        libraryStatus = text("ПРОВЕРКА", 11, mutedColor, true);
        first.addView(libraryStatus);
        stack(status, first, 16);
        LinearLayout second = horizontal();
        second.addView(text("AndKittyInjector · ZIP", 16, textColor, true), new LinearLayout.LayoutParams(0, -2, 1));
        injectorStatus = text("ПРОВЕРКА", 11, mutedColor, true);
        second.addView(injectorStatus);
        stack(status, second, 22);
        stack(body, status, 24);

        LinearLayout target = card(18);
        stack(target, text("ЦЕЛЕВОЕ ПРИЛОЖЕНИЕ", 11, mutedColor, true), 0);
        stack(target, text("PUBG Mobile · Vietnam", 19, textColor, true), 11);
        stack(target, text("Запуск через Android без остановки игрового процесса", 12, mutedColor, false), 5);
        stack(body, target, 13);

        prepareButton = primary("Обновить и запустить", true);
        stack(body, prepareButton, 25);
        prepareButton.setOnClickListener(view -> confirmRootLoad(true));
        downloadButton = primary("Обновить компоненты", false);
        stack(body, downloadButton, 11);
        downloadButton.setOnClickListener(view -> prepareFiles(false));
        launchButton = primary("Запустить с сохранёнными файлами", false);
        stack(body, launchButton, 11);
        launchButton.setOnClickListener(view -> confirmRootLoad(false));

        LinearLayout progress = card(17);
        progressText = text("Готов к работе", 14, textColor, true);
        stack(progress, progressText, 0);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(accentColor));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(surfaceHighColor));
        stack(progress, progressBar, 14);
        stack(body, progress, 25);

        TextView hint = text("Вкладка «Конфиги» содержит профили. Цвета элементов можно менять в профиле и внутри меню Phoenix.", 13, mutedColor, false);
        hint.setLineSpacing(dp(4), 1f);
        stack(body, hint, 20);
        renderFileStatuses();
        setWorking(busy);
    }

    private void renderNav(LinearLayout shell) {
        LinearLayout nav = horizontal();
        nav.setPadding(dp(13), dp(8), dp(13), dp(13));
        nav.setBackgroundColor(surfaceColor);
        String[] captions = {"⌂  Главная", "▦  Конфиги", "⚙  Настройки"};
        for (int i = 0; i < captions.length; i++) {
            final int target = i;
            TextView tab = text(captions[i], 12, i == page ? onAccentColor : mutedColor, true);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(4), dp(14), dp(4), dp(14));
            ripple(tab, i == page ? accentColor : surfaceHighColor, 19);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
            if (i > 0) params.leftMargin = dp(7);
            nav.addView(tab, params);
            tab.setOnClickListener(view -> showPage(target));
        }
        stack(shell, nav, 0);
    }

    private void renderProfiles(LinearLayout body) {
        stack(body, text("Мои конфиги", 28, textColor, true), 34);
        stack(body, text("Создавай пресеты, меняй цвета и активируй нужный перед запуском.", 14, mutedColor, false), 9);
        Button create = primary("＋  Создать конфиг", true);
        stack(body, create, 22);
        create.setOnClickListener(view -> createProfileDialog());
        String selected = ProfilesProvider.activeName(this);
        for (File file : ProfilesProvider.list(this)) {
            final String name = file.getName().substring(0, file.getName().length() - 4);
            final boolean active = name.equals(selected);
            LinearLayout block = card(17);
            LinearLayout heading = horizontal();
            TextView label = text(name, 19, textColor, true);
            heading.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            if (active) {
                TextView badge = text("● АКТИВЕН", 10, accentColor, true);
                badge.setPadding(dp(8), dp(7), dp(8), dp(7));
                badge.setBackground(rounded(surfaceHighColor, 12));
                heading.addView(badge);
            }
            stack(block, heading, 0);
            stack(block, text("Настройки ESP и индивидуальные цвета", 12, mutedColor, false), 8);
            LinearLayout actions = horizontal();
            Button edit = primary("Цвета и ESP", false);
            actions.addView(edit, new LinearLayout.LayoutParams(0, -2, 1));
            edit.setOnClickListener(view -> {
                if (!active) {
                    try { ProfilesProvider.select(this, name); } catch (IOException e) { showIssue("Конфиг", e.getMessage()); return; }
                }
                showProfileEditor();
            });
            Button menu = primary("⋯", false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(60), -2);
            p.leftMargin = dp(8);
            actions.addView(menu, p);
            menu.setOnClickListener(view -> profileActions(name));
            stack(block, actions, 15);
            stack(body, block, 13);
        }
        stack(body, text("Профили сохраняются во внутренней памяти Loader. Нативное меню использует выбранный здесь профиль.", 12, mutedColor, false), 18);
    }

    private void profileActions(String name) {
        String[] actions = name.equals(ProfilesProvider.DEFAULT)
                ? new String[]{"Активировать", "Создать копию"}
                : new String[]{"Активировать", "Создать копию", "Удалить"};
        new AlertDialog.Builder(this).setTitle(name).setItems(actions, (d, which) -> {
            if (which == 0) {
                try { ProfilesProvider.select(this, name); showPage(1); }
                catch (IOException error) { showIssue("Конфиг", error.getMessage()); }
            } else if (which == 1) createProfileDialog();
            else new AlertDialog.Builder(this).setTitle("Удалить «" + name + "»?")
                    .setMessage("Отменить удаление нельзя.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (dialog, b) -> {
                        try { ProfilesProvider.delete(this, name); showPage(1); }
                        catch (IOException error) { showIssue("Удаление", error.getMessage()); }
                    }).show();
        }).show();
    }

    private void createProfileDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(textColor);
        input.setHint("Например, My preset");
        input.setPadding(dp(16), dp(14), dp(16), dp(14));
        new AlertDialog.Builder(this).setTitle("Новый конфиг")
                .setMessage("Будет создан на основе текущего профиля")
                .setView(input)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Создать", (d, which) -> {
                    try {
                        String name = input.getText().toString().trim();
                        ProfilesProvider.create(this, name, ProfilesProvider.activeName(this));
                        ProfilesProvider.select(this, name);
                        showPage(1);
                    } catch (Exception error) { showIssue("Новый конфиг", messageOf(error)); }
                }).show();
    }

    private void showProfileEditor() {
        final File profile = ProfilesProvider.file(this, ProfilesProvider.activeName(this));
        final Properties props = new Properties();
        try (FileInputStream input = new FileInputStream(profile)) { props.load(input); }
        catch (IOException error) { showIssue("Чтение конфига", messageOf(error)); return; }
        ScrollView scroll = new ScrollView(this);
        LinearLayout items = vertical();
        items.setPadding(dp(20), dp(10), dp(20), dp(18));
        scroll.addView(items);
        stack(items, text("Точки цвета открывают палитру RGB. Для каждого элемента свой цвет.", 12, mutedColor, false), 0);
        for (int i = 0; i < VISUAL_KEYS.length; i++) {
            final String key = VISUAL_KEYS[i];
            final String property = "visual." + key;
            final String colorProperty = "color." + key;
            LinearLayout row = horizontal();
            CheckBox toggle = new CheckBox(this);
            toggle.setButtonTintList(ColorStateList.valueOf(accentColor));
            toggle.setText(VISUAL_LABELS[i]);
            toggle.setTextSize(14);
            toggle.setTextColor(textColor);
            toggle.setChecked("1".equals(props.getProperty(property, "0")));
            row.addView(toggle, new LinearLayout.LayoutParams(0, -2, 1));
            toggle.setOnCheckedChangeListener((button, checked) ->
                    props.setProperty(property, checked ? "1" : "0"));
            final int fallbackColor = COLOR_DEFAULTS[i];
            TextView swatch = text("●", 29, parseArgb(props.getProperty(colorProperty), fallbackColor), true);
            swatch.setGravity(Gravity.CENTER);
            swatch.setContentDescription("Цвет: " + VISUAL_LABELS[i]);
            ripple(swatch, surfaceHighColor, 18);
            row.addView(swatch, new LinearLayout.LayoutParams(dp(50), dp(44)));
            swatch.setOnClickListener(view -> openColorPicker(props, colorProperty, swatch));
            stack(items, row, 5);
        }
        stack(items, text("Прицеливание · FOV", 18, textColor, true), 22);
        stack(items, text("Режим «Угол» до 360°; от 170° — все цели, видимые на экране. "
                + "Режим «Радиус» задаётся в пикселях. Цели за камерой не обнаруживаются.",
                12, mutedColor, false), 7);

        if (!props.containsKey("combat.aimFovDegrees")) {
            int legacy = parseConfigInt(props.getProperty("combat.aimFov"), 1);
            int[] angles = {30, 60, 90, 120};
            props.setProperty("combat.aimFovDegrees", String.valueOf(angles[Math.max(0, Math.min(3, legacy))]));
        }
        if (!props.containsKey("combat.aimSmoothValue")) {
            int legacy = parseConfigInt(props.getProperty("combat.aimSmooth"), 1);
            int[] smooth = {1, 3, 6, 10};
            props.setProperty("combat.aimSmoothValue", String.valueOf(smooth[Math.max(0, Math.min(3, legacy))]));
        }

        CheckBox radiusMode = new CheckBox(this);
        radiusMode.setText("Радиус в пикселях вместо угла");
        radiusMode.setTextColor(textColor);
        radiusMode.setTextSize(14);
        radiusMode.setButtonTintList(ColorStateList.valueOf(accentColor));
        radiusMode.setChecked("1".equals(props.getProperty("combat.aimFovMode", "0")));
        radiusMode.setOnCheckedChangeListener((button, checked) ->
                props.setProperty("combat.aimFovMode", checked ? "1" : "0"));
        stack(items, radiusMode, 12);
        addProfileRange(items, props, "Угол FOV", "combat.aimFovDegrees", 5, 360, 60, 1.0f, "°");
        addProfileRange(items, props, "Радиус FOV", "combat.aimRadiusPx", 20, 360, 220, 1.0f, " px");
        addProfileRange(items, props, "Плавность прицеливания", "combat.aimSmoothValue", 1, 20, 3, 1.0f, "");
        addProfileRange(items, props, "Толщина круга FOV", "ui.fovCircleThickness", 5, 40, 12, 10.0f, " px");

        LinearLayout circleRow = horizontal();
        circleRow.addView(text("Цвет круга FOV", 14, textColor, false),
                new LinearLayout.LayoutParams(0, -2, 1));
        TextView circleSwatch = text("●", 29,
                parseArgb(props.getProperty("color.fovCircle"), 0x5fd4d4d8), true);
        circleSwatch.setGravity(Gravity.CENTER);
        ripple(circleSwatch, surfaceHighColor, 18);
        circleRow.addView(circleSwatch, new LinearLayout.LayoutParams(dp(50), dp(44)));
        circleSwatch.setOnClickListener(view ->
                openColorPicker(props, "color.fovCircle", circleSwatch));
        stack(items, circleRow, 12);

        new AlertDialog.Builder(this).setTitle("Редактор · " + ProfilesProvider.activeName(this))
                .setView(scroll)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (dialog, index) -> {
                    try (FileOutputStream out = new FileOutputStream(profile)) {
                        props.store(out, "Phoenix config");
                        out.getFD().sync();
                        Toast.makeText(this, "Конфиг сохранён", Toast.LENGTH_SHORT).show();
                    } catch (IOException error) { showIssue("Сохранение", messageOf(error)); }
                }).show();
    }

    private static int parseConfigInt(String value, int fallback) {
        if (value == null) return fallback;
        try { return Integer.parseInt(value.trim()); }
        catch (NumberFormatException e) { return fallback; }
    }

    // FOV and appearance settings live in the same .cfg as the ESP colors.
    private void addProfileRange(LinearLayout parent, Properties props, String caption,
                                 String key, int min, int max, int defaultValue,
                                 float divisor, String unit) {
        float initial = defaultValue / divisor;
        try { initial = Float.parseFloat(props.getProperty(key, "")); }
        catch (NumberFormatException ignored) { }
        if (Float.isNaN(initial) || Float.isInfinite(initial)) initial = defaultValue / divisor;
        int start = Math.max(min, Math.min(max, Math.round(initial * divisor)));
        TextView label = text(caption + " · "
                + String.format(Locale.US, divisor == 1.0f ? "%.0f" : "%.1f", start / divisor)
                + unit, 13, textColor, false);
        stack(parent, label, 15);
        SeekBar slider = new SeekBar(this);
        slider.setMax(max - min);
        slider.setProgress(start - min);
        slider.setProgressTintList(ColorStateList.valueOf(accentColor));
        stack(parent, slider, 3);
        props.setProperty(key, String.format(Locale.US, "%.2f", start / divisor));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean user) {
                float current = (value + min) / divisor;
                props.setProperty(key, String.format(Locale.US, "%.2f", current));
                label.setText(caption + " · "
                        + String.format(Locale.US, divisor == 1.0f ? "%.0f" : "%.1f", current)
                        + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
    }

    private void openColorPicker(Properties props, String key, TextView swatch) {
        int selected = parseArgb(props.getProperty(key), 0xffffffff);
        int[] rgba = {Color.red(selected), Color.green(selected), Color.blue(selected), Color.alpha(selected)};
        LinearLayout layout = vertical();
        layout.setPadding(dp(24), dp(12), dp(24), dp(8));
        final TextView preview = text("●  Превью цвета", 19, selected, true);
        stack(layout, preview, 4);
        String[] channels = {"R · красный", "G · зелёный", "B · синий", "A · прозрачность"};
        for (int i = 0; i < 4; i++) {
            final int channel = i;
            stack(layout, text(channels[i], 12, mutedColor, false), 14);
            SeekBar seek = new SeekBar(this);
            seek.setMax(255);
            seek.setProgress(rgba[i]);
            seek.setProgressTintList(ColorStateList.valueOf(accentColor));
            stack(layout, seek, 2);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int value, boolean user) {
                    rgba[channel] = value;
                    preview.setTextColor(Color.argb(rgba[3], rgba[0], rgba[1], rgba[2]));
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });
        }
        new AlertDialog.Builder(this).setTitle("Настроить цвет")
                .setView(layout)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Выбрать", (dialog, index) -> {
                    int value = Color.argb(rgba[3], rgba[0], rgba[1], rgba[2]);
                    props.setProperty(key, String.format(Locale.US, "%08X", value));
                    swatch.setTextColor(value);
                }).show();
    }

    private static int parseArgb(String text, int fallback) {
        if (text == null) return fallback;
        try { return (int) Long.parseLong(text.replace("#", "").trim(), 16); }
        catch (NumberFormatException error) { return fallback; }
    }

    private void renderPreferences(LinearLayout body) {
        stack(body, text("Настройки", 28, textColor, true), 34);
        stack(body, text("Phoenix настроен для ARM64 и PUBG Mobile VN.", 14, mutedColor, false), 7);
        LinearLayout panel = card(20);
        stack(panel, text("Материал и оформление", 18, textColor, true), 0);
        stack(panel, text("Динамическая цветовая палитра Material You применяется на Android 12 и выше. На старых версиях используется тема Phoenix.", 13, mutedColor, false), 9);
        stack(panel, text("Сервер библиотеки", 14, textColor, true), 22);
        TextView server = text(SO_URL, 12, accentColor, false);
        server.setTextIsSelectable(true);
        stack(panel, server, 8);
        stack(panel, text("Выбранный конфиг: " + ProfilesProvider.activeName(this), 14, textColor, true), 18);
        stack(body, panel, 20);
        Button troubleshoot = primary("Как исправить ошибку запуска?", false);
        stack(body, troubleshoot, 16);
        troubleshoot.setOnClickListener(view -> showIssue("Диагностика",
                "Если нет root — разреши su для Phoenix. При ошибке загрузки проверь интернет и наличие файлов. "
                + "При ошибке выполнения проверь код возврата. Принудительное отключение SELinux не используется."));
    }

    private void setWorking(boolean working) {
        if (prepareButton != null) prepareButton.setEnabled(!working);
        if (downloadButton != null) downloadButton.setEnabled(!working);
        if (launchButton != null) launchButton.setEnabled(!working);
    }

    private void showIssue(String title, String message) {
        if (destroyed || isFinishing()) return;
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setPositiveButton("Понятно", null).show();
    }

    private void showLaunchIssue(String message) {
        String title = "Не удалось выполнить команду";
        if (message.contains("su") || message.contains("root") || message.contains("Permission denied"))
            title = "Недостаточно root-прав";
        else if (message.contains("HTTP") || message.contains("сеть") || message.contains("connect"))
            title = "Ошибка загрузки компонентов";
        else if (message.contains("PUBG") || message.contains("process not ready"))
            title = "Игра не готова";
        showIssue(title, message);
    }

    private void confirmRootLoad(final boolean updateFiles) {
        if (busy || destroyed) return;
        new AlertDialog.Builder(this)
                .setTitle("Выполнить команду через root?")
                .setMessage("Phoenix Loader " + (updateFiles ? "обновит файлы, " : "использует сохранённые файлы, ")
                        + "подготовит их в /data/local/tmp, откроет PUBG Mobile VN "
                        + "и выполнит AndKittyInjector через su. "
                        + "Это запуск стороннего исполняемого файла с правами root. "
                        + "Принудительной остановки игры не будет.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Продолжить", (dialog, which) -> {
                    if (updateFiles) prepareFiles(true);
                    else loadPreparedFiles();
                })
                .show();
    }

    private void prepareFiles(final boolean launchAfterDownload) {
        if (busy || destroyed) return;
        busy = true;
        setWorking(true);
        if (progressBar != null) progressBar.setProgress(0);
        if (progressText != null) progressText.setText("Подключение к серверу...");
        log("Начата загрузка новой версии файлов");

        executor.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!workspace.isDirectory() && !workspace.mkdirs()) {
                        throw new IOException("Не удалось создать папку приложения");
                    }

                    stage(2, "Загрузка библиотеки Phoenix...");
                    downloadHttps(SO_URL, libraryFile, MAX_SO_BYTES, 3, 52);
                    verifyArm64Elf(libraryFile, "libPhoenix.so");
                    log("libPhoenix.so: " + libraryFile.length() + " байт");
                    log("SHA-256: " + sha256(libraryFile));

                    stage(58, "Загрузка архива AndKittyInjector...");
                    downloadHttps(INJECTOR_ZIP_URL, injectorZipFile,
                            MAX_ZIP_BYTES, 59, 23);
                    stage(84, "Поиск ARM64-файла внутри ZIP...");
                    unpackInjector(injectorZipFile, injectorFile);
                    verifyArm64Elf(injectorFile, "AndKittyInjector");
                    log("Архив распакован: AndKittyInjector найден");
                    stage(100, "Оба файла подготовлены");

                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            renderFileStatuses();
                            if (launchAfterDownload) {
                                // Keep busy and progress running until root operation has finished.
                                executeRootLoad();
                            } else {
                                finishWork();
                            }
                        }
                    });
                } catch (final Exception error) {
                    log("ОШИБКА: " + messageOf(error));
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            if (progressText != null) progressText.setText("Не удалось подготовить файлы");
                            renderFileStatuses();
                            finishWork();
                            showLaunchIssue(messageOf(error));
                        }
                    });
                }
            }
        });
    }

    private void finishWork() {
        busy = false;
        setWorking(false);
    }

    private void loadPreparedFiles() {
        if (busy || destroyed) return;
        if (!isArm64Elf(libraryFile) || !isArm64Elf(injectorFile)) {
            log("Сначала скачайте оба компонента");
            showIssue("Компоненты не подготовлены",
                    "Сначала скачай актуальную libPhoenix.so и AndKittyInjector.");
            return;
        }
        busy = true;
        setWorking(true);
        executeRootLoad();
    }

    private void executeRootLoad() {
        if (destroyed) return;
        executor.execute(new Runnable() {
            @Override public void run() {
                try {
                    verifyArm64Elf(libraryFile, "libPhoenix.so");
                    verifyArm64Elf(injectorFile, "AndKittyInjector");
                    stage(88, "Проверка root и подготовка файлов...");
                    log("Проверяем права su");
                    runRoot("test \"$(id -u)\" = 0", false);

                    // The original successful manual run used these public paths.
                    // Quote source paths even though they originate from getFilesDir().
                    String prepare = "set -e; "
                            + "cp " + shellQuote(libraryFile.getAbsolutePath())
                            + " " + shellQuote(PUBLIC_SO) + "; "
                            + "chmod 644 " + shellQuote(PUBLIC_SO) + "; "
                            + "cp " + shellQuote(injectorFile.getAbsolutePath())
                            + " " + shellQuote(PUBLIC_INJECTOR) + "; "
                            + "chmod 700 " + shellQuote(PUBLIC_INJECTOR) + "; "
                            + "test -s " + shellQuote(PUBLIC_SO) + "; "
                            + "test -x " + shellQuote(PUBLIC_INJECTOR);
                    runRoot(prepare, false);
                    log("Файлы подготовлены в /data/local/tmp");

                    final Intent intent = getPackageManager()
                            .getLaunchIntentForPackage(GAME_PACKAGE);
                    if (intent == null) {
                        throw new IOException("PUBG Mobile VN не установлена или недоступна");
                    }

                    stage(92, "Открытие игры без остановки процесса...");
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (destroyed) return;
                            try {
                                startActivity(intent);
                                log("Игра открыта через Intent");
                            } catch (Exception error) {
                                log("Ошибка открытия игры: " + messageOf(error));
                            }
                        }
                    });

                    // Wait until the target's native engine has appeared.
                    // Do not kill/restart the game; target may already be running.
                    stage(95, "Ожидание готовности процесса...");
                    String injection = "found=0; n=0; "
                            + "while [ \"$n\" -lt 120 ]; do "
                            + "  pid=$(pidof " + GAME_PACKAGE + " 2>/dev/null); "
                            + "  pid=${pid%% *}; "
                            + "  if [ -n \"$pid\" ] && [ -r \"/proc/$pid/maps\" ] "
                            + "     && grep -q 'libUE4.so' \"/proc/$pid/maps\"; then "
                            + "    found=1; break; "
                            + "  fi; "
                            + "  sleep 1; n=$((n + 1)); "
                            + "done; "
                            + "if [ \"$found\" -ne 1 ]; then echo 'PUBG process not ready'; exit 124; fi; "
                            + "sleep 5; "
                            + shellQuote(PUBLIC_INJECTOR)
                            + " --package " + shellQuote(GAME_PACKAGE)
                            + " --libs " + shellQuote(PUBLIC_SO);
                    stage(97, "Выполнение команды AndKittyInjector через su...");
                    runRoot(injection, true);
                    stage(100, "Команда завершилась успешно");
                    log("[+] Root-команда выполнена успешно");
                } catch (final Exception error) {
                    log("ОШИБКА: " + messageOf(error));
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) {
                                if (progressText != null) progressText.setText("Ошибка запуска");
                                showLaunchIssue(messageOf(error));
                            }
                        }
                    });
                } finally {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) {
                                finishWork();
                                setFileStatus(libraryStatus, isArm64Elf(libraryFile));
                                setFileStatus(injectorStatus, isArm64Elf(injectorFile));
                            }
                        }
                    });
                }
            }
        });
    }

    /** One safely quoted POSIX-shell argument. */
    private static String shellQuote(String value) {
        return "'" + value.replace("'", "'\"'\"'") + "'";
    }

    /** Run a single explicit command under su and record its stdout/stderr. */
    private void runRoot(String command, boolean showOutput) throws IOException {
        Process process = null;
        StringBuilder recentOutput = new StringBuilder();
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            activeRootProcess = process;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (showOutput) log("[root] " + line);
                    recentOutput.append(line).append('\n');
                    if (recentOutput.length() > 4000) {
                        recentOutput.delete(0, recentOutput.length() - 4000);
                    }
                }
            }
            int code = process.waitFor();
            if (code != 0) {
                String details = recentOutput.toString().trim();
                if (details.length() > 180) {
                    details = details.substring(details.length() - 180);
                }
                throw new IOException("su: код выхода " + code
                        + (details.isEmpty() ? "" : ": " + details));
            }
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new IOException("Root-команда прервана", error);
        } finally {
            activeRootProcess = null;
            if (process != null) process.destroy();
        }
    }

    private void renderFileStatuses() {
        boolean libraryOk = isArm64Elf(libraryFile);
        boolean injectorOk = isArm64Elf(injectorFile);
        setFileStatus(libraryStatus, libraryOk);
        setFileStatus(injectorStatus, injectorOk);
        if (libraryOk && injectorOk && !busy) {
            if (progressText != null) progressText.setText("Компоненты готовы");
            if (progressBar != null) progressBar.setProgress(100);
        }
    }

    private void setFileStatus(TextView view, boolean ready) {
        if (view == null) return;
        view.setText(ready ? "● ГОТОВО" : "○ НЕ ГОТОВО");
        view.setTextColor(ready ? accentColor : errorColor);
    }

    private void stage(final int percent, final String text) {
        log(text);
        ui.post(new Runnable() {
            @Override public void run() {
                if (destroyed) return;
                if (progressBar != null) progressBar.setProgress(percent);
                if (progressText != null) progressText.setText(text);
            }
        });
    }

    /** Download to a temporary file, then replace only after full transfer. */
    private void downloadHttps(String address, File target, long maxBytes,
                               int progressBase, int progressSpan) throws IOException {
        HttpURLConnection connection = openHttps(address);
        File temporary = File.createTempFile(".phoenix-", ".download", workspace);
        try {
            long declaredSize = connection.getContentLengthLong();
            if (declaredSize > maxBytes) {
                throw new IOException("Файл слишком большой");
            }
            long total = 0;
            byte[] buffer = new byte[16384];
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream output = new FileOutputStream(temporary)) {
                int count;
                int lastPercent = -1;
                while ((count = input.read(buffer)) != -1) {
                    if (count == 0) continue;
                    total += count;
                    if (total > maxBytes) throw new IOException("Лимит размера превышен");
                    output.write(buffer, 0, count);
                    if (declaredSize > 0) {
                        int part = (int) Math.min(progressSpan,
                                (total * progressSpan) / declaredSize);
                        int percent = progressBase + part;
                        if (percent > lastPercent) {
                            lastPercent = percent;
                            final int progress = percent;
                            ui.post(new Runnable() {
                                @Override public void run() {
                                    if (!destroyed && progressBar != null) progressBar.setProgress(progress);
                                }
                            });
                        }
                    }
                }
                output.getFD().sync();
            }
            if (total == 0) throw new IOException("Сервер прислал пустой файл");
            // Never replace the last usable file with an invalid download.
            if ("libPhoenix.so".equals(target.getName())) {
                verifyArm64Elf(temporary, "libPhoenix.so");
            } else if ("arm64-v8a.zip".equals(target.getName())) {
                verifyZipSignature(temporary);
            }
            if (!temporary.renameTo(target)) {
                throw new IOException("Не удалось сохранить " + target.getName());
            }
        } finally {
            connection.disconnect();
            if (temporary.exists()) temporary.delete();
        }
    }

    /** Follow HTTPS redirects, including GitHub release asset redirects. */
    private HttpURLConnection openHttps(String address) throws IOException {
        URL current = new URL(address);
        for (int i = 0; i < 8; i++) {
            if (!"https".equalsIgnoreCase(current.getProtocol())) {
                throw new IOException("Разрешён только HTTPS");
            }
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(45000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Cache-Control", "no-cache");
            connection.setRequestProperty("User-Agent", "Phoenix-Loader/4.0");
            int status;
            try {
                status = connection.getResponseCode();
            } catch (IOException error) {
                connection.disconnect();
                throw error;
            }
            if (status == 301 || status == 302 || status == 303 ||
                    status == 307 || status == 308) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("Нет адреса перенаправления");
                current = new URL(current, location);
                continue;
            }
            if (status != HttpURLConnection.HTTP_OK) {
                connection.disconnect();
                throw new IOException("HTTP " + status + " для " + current.getHost());
            }
            return connection;
        }
        throw new IOException("Слишком много перенаправлений");
    }

    private void verifyZipSignature(File file) throws IOException {
        byte[] header = new byte[4];
        try (InputStream input = new FileInputStream(file)) {
            int offset = 0;
            while (offset < 4) {
                int n = input.read(header, offset, 4 - offset);
                if (n < 0) break;
                offset += n;
            }
            if (offset != 4 || header[0] != 'P' || header[1] != 'K' ||
                    header[2] != 3 || header[3] != 4) {
                throw new IOException("Сервер вернул не ZIP-архив");
            }
        }
    }

    /** Extract only the executable, regardless of the archive's parent directory. */
    private void unpackInjector(File archive, File destination) throws IOException {
        File temporary = File.createTempFile(".injector-", ".tmp", workspace);
        boolean found = false;
        try {
            try (ZipInputStream zip = new ZipInputStream(
                    new BufferedInputStream(new FileInputStream(archive)))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String path = entry.getName().replace('\\', '/');
                    String basename = path.substring(path.lastIndexOf('/') + 1);
                    if (!entry.isDirectory() && "AndKittyInjector".equals(basename)) {
                        long count = 0;
                        try (OutputStream output = new BufferedOutputStream(
                                new FileOutputStream(temporary))) {
                            byte[] buffer = new byte[8192];
                            int n;
                            while ((n = zip.read(buffer)) != -1) {
                                if (n == 0) continue;
                                count += n;
                                if (count > MAX_INJECTOR_BYTES) {
                                    throw new IOException("Исполняемый файл слишком большой");
                                }
                                output.write(buffer, 0, n);
                            }
                        }
                        if (count == 0) throw new IOException("Пустой AndKittyInjector");
                        found = true;
                        zip.closeEntry();
                        break;
                    }
                    zip.closeEntry();
                }
            }
            if (!found) {
                throw new IOException("AndKittyInjector не найден внутри ZIP");
            }
            verifyArm64Elf(temporary, "AndKittyInjector");
            if (!temporary.renameTo(destination)) {
                throw new IOException("Не удалось сохранить AndKittyInjector");
            }
        } finally {
            if (temporary.exists()) temporary.delete();
        }
    }

    private boolean isArm64Elf(File file) {
        try {
            verifyArm64Elf(file, "Файл");
            return true;
        } catch (IOException error) {
            return false;
        }
    }

    private void verifyArm64Elf(File file, String name) throws IOException {
        if (file == null || !file.isFile() || file.length() < 20) {
            throw new IOException(name + ": файл отсутствует или повреждён");
        }
        byte[] magic = new byte[20];
        try (InputStream input = new FileInputStream(file)) {
            int read = 0;
            while (read < magic.length) {
                int n = input.read(magic, read, magic.length - read);
                if (n < 0) break;
                read += n;
            }
            if (read != magic.length || magic[0] != 0x7f || magic[1] != 'E' ||
                    magic[2] != 'L' || magic[3] != 'F' || magic[4] != 2 ||
                    magic[5] != 1 || (magic[18] & 0xff) != 183 || magic[19] != 0) {
                throw new IOException(name + ": ожидается ELF ARM64");
            }
        }
    }

    private String sha256(File file) throws IOException {
        final MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException error) {
            throw new IOException("SHA-256 недоступен", error);
        }
        try (InputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (count > 0) digest.update(buffer, 0, count);
            }
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte b : digest.digest()) {
            hex.append(String.format(Locale.US, "%02x", b & 0xff));
        }
        return hex.toString();
    }

    private void log(final String message) {
        android.util.Log.i("Phoenix", message);
    }

    private static String messageOf(Throwable error) {
        String text = error.getMessage();
        return text == null || text.trim().isEmpty()
                ? error.getClass().getSimpleName() : text;
    }
}
